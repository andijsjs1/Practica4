#include "headers/Menu.h"

int main() {
    Menu menu;
    menu.ejecutar();
    return 0;
}
