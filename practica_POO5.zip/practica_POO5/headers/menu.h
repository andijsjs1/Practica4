#ifndef MENU_H
#define MENU_H

#include "Controller.h"

class Menu {
private:
    Controller controller;

public:
    void ejecutar();
};

#endif
